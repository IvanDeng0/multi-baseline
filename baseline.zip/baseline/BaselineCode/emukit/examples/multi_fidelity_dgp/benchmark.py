from prettytable import PrettyTable
import numpy as np
import scipy.stats
from sklearn.metrics import mean_squared_error, r2_score
import emukit.examples.multi_fidelity_dgp
from emukit.examples.multi_fidelity_dgp.baseline_model_wrappers import LinearAutoRegressiveModel, NonLinearAutoRegressiveModel, HighFidelityGp
from emukit.core import ContinuousParameter, ParameterSpace
from emukit.core.initial_designs import LatinDesign
#from emukit.examples.multi_fidelity_dgp.multi_fidelity_deep_gp import MultiFidelityDeepGP
from emukit.test_functions.multi_fidelity import (multi_fidelity_borehole_function, multi_fidelity_branin_function,
                                                  multi_fidelity_park_function, multi_fidelity_hartmann_3d,
                                                  multi_fidelity_currin_function)
from collections import namedtuple
from emukit.examples.multi_fidelity_dgp.ResGP import resGP
import torch


Function = namedtuple('Function', ['name', 'y_scale', 'noise_level', 'do_x_scaling', 'num_data', 'fcn'])

borehole = Function(name='borehole', y_scale=100, noise_level=[0.0, 0.0], do_x_scaling=True, num_data=[60, 10],
                    fcn=multi_fidelity_borehole_function)
branin = Function(name='branin', y_scale=1, noise_level=[0., 0., 0.], do_x_scaling=False, num_data=[80, 30, 10],
                    fcn=multi_fidelity_branin_function)
currin = Function(name='currin', y_scale=1, noise_level=[0., 0.], do_x_scaling=False, num_data=[20, 5],
                    fcn=multi_fidelity_currin_function)
park = Function(name='park', y_scale=1, noise_level=[0., 0.], do_x_scaling=False, num_data=[30, 5],
                    fcn=multi_fidelity_park_function)
hartmann_3d = Function(name='hartmann', y_scale=1, noise_level=[0., 0., 0.], do_x_scaling=False, num_data=[80, 30, 10],
                    fcn=multi_fidelity_hartmann_3d)


# Function to repeat test across different random seeds.
def do_benchmark(fcn_tuple):
    metrics = dict()

    # Some random seeds to use
    seeds = [1]

    for i, seed in enumerate(seeds):
        run_name = str(seed) + str(fcn_tuple.num_data)
        metrics[run_name] = test_function(fcn_tuple, seed)
        print('After ' + str(i+1) + ' runs of ' + fcn_tuple.name)
        print_metrics(metrics)

    return metrics


# Print metrics as table
def print_metrics(metrics):
    model_names = list(list(metrics.values())[0].keys())
    metric_names = ['r2', 'mnll', 'rmse']
    table = PrettyTable(['model'] + metric_names)

    for name in model_names:
        mean = []
        for metric_name in metric_names:
            mean.append(np.mean([metric[name][metric_name] for metric in metrics.values()]))
        table.add_row([name] + mean)

    print(table)


def test_function(fcn, seed):
    np.random.seed(seed)

    x_test, y_test, X, Y = generate_data(fcn, 1000)

    #mf_dgp_fix_lf_mean = MultiFidelityDeepGP(X, Y, n_iter=5000)
    #mf_dgp_fix_lf_mean.name = 'mf_dgp_fix_lf_mean'


    #models = [HighFidelityGp(X, Y), LinearAutoRegressiveModel(X, Y), NonLinearAutoRegressiveModel(X, Y), mf_dgp_fix_lf_mean]
    models = [HighFidelityGp(X, Y), LinearAutoRegressiveModel(X, Y), NonLinearAutoRegressiveModel(X, Y)]
    return benchmark_models(models, x_test, y_test)


def benchmark_models(models, x_test, y_test):
    metrics = dict()
    for model in models:
        model.optimize()
        y_mean, y_var = model.predict(x_test)
        metrics[model.name] = calculate_metrics(y_test, y_mean, y_var)
        print('+ ######################## +')
        print(model.name, 'r2', metrics[model.name]['r2'])
        print('+ ######################## + ')
    return metrics


def generate_data(fcn_tuple, n_test_points):
    """
    Generates train and test data for
    """

    # A different definition of the parameter space for the branin function was used in the paper
    if fcn_tuple.name == 'branin':
        fcn, space = fcn_tuple.fcn()
        new_space = ParameterSpace([ContinuousParameter('x1', -5., 0.), ContinuousParameter('x2', 10., 15.)])
    else:
        fcn, space = fcn_tuple.fcn()
        new_space = ParameterSpace(space._parameters[:-1])

    do_x_scaling = fcn_tuple.do_x_scaling

    # Generate training data

    latin = LatinDesign(new_space)
    #X = [latin.get_samples(n) for n in fcn_tuple.num_data]
    mask_list = []
    for n in fcn_tuple.num_data:
        mask_list.append(torch.randperm(fcn_tuple.num_data[0])[0: n])
    latin_samples = latin.get_samples(fcn_tuple.num_data[0])
    X = [latin_samples[mask_list[n], :] for n in range(len(mask_list))]

    # Scale X if required
    if do_x_scaling:
        scalings = X[0].std(axis=0)
    else:
        scalings = np.ones(X[0].shape[1])

    for x in X:
        x /= scalings

    Y_for_emu = []
    for i, x in enumerate(X):
        Y_for_emu.append(fcn.f[i](x * scalings) / fcn_tuple.y_scale)

    Y_for_res = [fcn.f[i](X[0] * scalings) / fcn_tuple.y_scale for i in range(len(mask_list))]

    y_scale = fcn_tuple.y_scale

    # scale y and add noise if required
    noise_levels = fcn_tuple.noise_level
    if any([n > 0 for n in noise_levels]):
        for y, std_noise in zip(Y_for_emu, noise_levels):
            y /= y_scale + std_noise * np.random.randn(y.shape[0], 1)

    # Generate test data
    x_test = latin.get_samples(n_test_points)
    x_test /= scalings
    y_test = fcn.f[len(mask_list) - 1](x_test * scalings)
    y_test /= y_scale
    x_test_res = x_test
    i_highest_fidelity = (len(fcn_tuple.num_data) - 1) * np.ones((x_test.shape[0], 1))
    x_test = np.concatenate([x_test, i_highest_fidelity], axis=1)
    #print(X[1].shape)
    return x_test_res, x_test, y_test, X, Y_for_emu, Y_for_res, mask_list


def calculate_metrics(y_test, y_mean_prediction, y_var_prediction):
    # R2
    r2 = r2_score(y_test, y_mean_prediction)
    # RMSE
    rmse = np.sqrt(mean_squared_error(y_test, y_mean_prediction))
    # Test log likelihood
    mnll = -np.sum(scipy.stats.norm.logpdf(y_test, loc=y_mean_prediction, scale=np.sqrt(y_var_prediction)))/len(y_test)
    return {'r2': r2, 'rmse': rmse, 'mnll': mnll}


def auto_test(fcn_tuple):
    seeds = [1, 2, 3, 4, 5, 6, 7]
    fcn_name = fcn_tuple.name
    for i, seed in enumerate(seeds):
        np.random.seed(seed)
        x_test, y_test, x_train, y_train, mask_list = generate_data(fcn_tuple, 1000)
        for j, data_f in enumerate(x_train):
            np.savetxt(fcn_name + '_' + 'xtrain' + '_' + str(j) + '_seed_' + str(i) + '.csv', data_f, delimiter=',')
        for j, data_f in enumerate(y_train):
            np.savetxt(fcn_name + '_' + 'ytrain' + '_' + str(j) + '_seed_' + str(i) + '.csv', data_f, delimiter=',')
        np.savetxt(fcn_name + '_' + 'xtest' + '_' + 'seed_' + str(i) + '.csv', x_test, delimiter=',')
        np.savetxt(fcn_name + '_' + 'ytest' + '_' + 'seed_' + str(i) + '.csv', y_test, delimiter=',')
        models = [HighFidelityGp(x_train, y_train), LinearAutoRegressiveModel(x_train, y_train), NonLinearAutoRegressiveModel(x_train, y_train)]
        for model in models:
            model.optimize()
            y_pred, y_var = model.predict(x_test)
            np.savetxt(fcn_name + '_' + 'ypred' + '_' + model.name + '_seed_' + str(i) + '.csv', y_pred, delimiter=',')
            np.savetxt(fcn_name + '_' + 'yvar' + '_' + model.name + '_seed_' + str(i) + '.csv', y_var, delimiter=',')


def auto_compare(fcn_tuple, ite):
    seeds = [92, 351, 472, 145, 167, 222]
    fcn_name = fcn_tuple.name
    result = dict()
    for k, seed in enumerate(seeds):
        metrics = dict()
        np.random.seed(seed)
        x_test_res, x_test, y_test, x_train, y_train_emu, y_train_res, mask_list = generate_data(fcn_tuple, 1000)

        xte_res = torch.from_numpy(x_test_res)
        yte_res = torch.from_numpy(y_test)

        xtr_res = torch.from_numpy(x_train[0])
        ytr_res = [torch.from_numpy(y_train_res[i]) for i in range(len(y_train_res))]
        models = [HighFidelityGp(x_train, y_train_emu), LinearAutoRegressiveModel(x_train, y_train_emu),
                  NonLinearAutoRegressiveModel(x_train, y_train_emu), resGP(xtr_res, ytr_res, mask_list)]
        for i in range(len(models)):
            if i == 3:
                models[i].train_bfgs(ite, lr=0.01)
                with torch.no_grad():
                    ypred, yvar = models[i](xte_res)
                metrics['resGP'] = calculate_metrics(y_test, ypred.numpy(), yvar.numpy())
            else:
                models[i].optimize()
                ypred, yvar = models[i].predict(x_test)
                metrics[models[i].name] = calculate_metrics(y_test, ypred, yvar)

        result[fcn_name + '_seed=' + str(seed)] = metrics
        print('seed = ', seed, 'fcn = ', fcn_name)
        print_metrics(result)
    return result


# result_branin = auto_compare(branin, 500)
# print(result_branin)
# result_borehole = auto_compare(borehole, 3000)
# print(result_borehole)
# result_h3d = auto_compare(hartmann_3d, 500)
# print(result_h3d)
# result_park = auto_compare(park)
result_currin = auto_compare(currin, 500)
print(result_currin)
#print(result_branin, result_borehole, result_h3d, result_park, result_currin)






